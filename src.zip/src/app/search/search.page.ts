import { Component } from '@angular/core';

@Component({
  selector: 'app-search',
  templateUrl: './search.page.html',
  styleUrls: ['./search.page.scss'],
})
export class SearchPage {
  searchTerm = ''; // Valor inicial vazio para a propriedade searchTerm
  searchResults: any[] = []; // Inicializando a propriedade searchResults com um array vazio

  availableParts: any[] = [
    { name: 'nvidia rtx 3060', image: 'https://images.versus.io/objects/nvidia-geforce-rtx-3060.front.variety.1610630274718.jpg', price: this.getRandomPrice() },
    { name: 'rx 580', image: 'https://m.media-amazon.com/images/I/61FsgtdKejL._AC_UF1000,1000_QL80_.jpg', price: this.getRandomPrice() },
    { name: 'nvidia gtx 1050 ti', image: 'https://cdn.awsli.com.br/2500x2500/2013/2013584/produto/161536341/14e30f7f19.jpg', price: this.getRandomPrice() },
    { name: 'intel core i7', image: 'https://ae01.alicdn.com/kf/H1fde9fc1449d45f891f5e9722e014f22B/Processador-para-desktop-Intel-Core-i7-9700K-i7-9700K-8-n-cleos-at-3-6-GHz.jpg', price: this.getRandomPrice() },
    { name: 'intel core i5', image: 'https://m.media-amazon.com/images/I/4144foZwMVL.jpg', price: this.getRandomPrice() },
    { name: 'intel core i3', image: 'https://www.intel.com/content/dam/www/central-libraries/us/en/images/2022-11/badge-ci3-10th.png', price: this.getRandomPrice() }
    // Adicione mais peças disponíveis aqui...
  ];
  
  getRandomPrice(): number {
    // Gerar um preço aleatório entre 100 e 1000
    return Math.floor(Math.random() * (1000 - 100 + 1) + 100);
  }

  constructor() {
    // Atribuir um valor inicial para a propriedade searchTerm (opcional)
    // this.searchTerm = '';
  }

  performSearch() {
    if (this.searchTerm && this.searchTerm.trim() !== '') {
      this.searchResults = this.availableParts.filter(part =>
        part.name.toLowerCase().includes(this.searchTerm.toLowerCase())
      );
    } else {
      this.searchResults = [];
    }
  }
}
