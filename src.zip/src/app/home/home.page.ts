import { Component } from '@angular/core';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
})
export class HomePage {
  availableParts: any[] = [
    { name: 'Placas de vídeo disponíveis : rx 580 ; nvidia rtx 3060 ; nvidia gtx 1050 ti. ', image: 'https://m.media-amazon.com/images/I/61FsgtdKejL._AC_UF1000,1000_QL80_.jpg' },
    { name: 'Processadores disponíveis : intel core i7 ; intel core i5 ; intel core i3.', image: 'https://ae01.alicdn.com/kf/H1fde9fc1449d45f891f5e9722e014f22B/Processador-para-desktop-Intel-Core-i7-9700K-i7-9700K-8-n-cleos-at-3-6-GHz.jpg' },
    
    // Adicione mais peças disponíveis aqui...
  ];

  constructor(private navCtrl: NavController) {}

  goToSearchPage() {
    this.navCtrl.navigateForward('/search');
  }
}
